"""ChicagoFSWild dataset."""

from .chicagofswild import ChicagoFSWild
