from .ngt_corpus import NGTCorpus
