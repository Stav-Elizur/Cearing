"""signsuisse dataset."""

from .signsuisse import SignSuisse
