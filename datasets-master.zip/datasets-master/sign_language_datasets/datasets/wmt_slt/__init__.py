"""sign2mint dataset."""

from .wmt_slt import WMTSLT
