"""dgs_corpus dataset."""

from .dgs_corpus import DgsCorpus, DgsCorpusConfig
