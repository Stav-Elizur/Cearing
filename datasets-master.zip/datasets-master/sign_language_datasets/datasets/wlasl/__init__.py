"""wlasl dataset."""

from .wlasl import Wlasl
