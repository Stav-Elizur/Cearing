"""SignTyp dataset."""

from .signtyp import SignTyp
