"""dgs_types dataset."""

from .dgs_types import DgsTypes
