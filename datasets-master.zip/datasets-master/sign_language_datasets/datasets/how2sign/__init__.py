"""how2sign dataset."""

from .how2sign import How2Sign
