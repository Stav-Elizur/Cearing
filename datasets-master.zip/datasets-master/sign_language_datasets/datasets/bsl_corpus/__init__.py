"""bsl_corpus dataset."""

from .bsl_corpus import BslCorpus
