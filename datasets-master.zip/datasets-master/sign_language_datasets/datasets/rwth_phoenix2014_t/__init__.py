"""rwth_phoenix_2014_t dataset."""

from .rwth_phoenix2014_t import RWTHPhoenix2014T
