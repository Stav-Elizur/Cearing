"""autsl dataset."""

from .autsl import AUTSL
